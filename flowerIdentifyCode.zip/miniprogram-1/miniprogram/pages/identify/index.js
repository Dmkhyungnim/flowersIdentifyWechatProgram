import { RESULT } from '../../itemMap.js';
import * as paddlejs from '@paddlejs/paddlejs-core';
import '@paddlejs/paddlejs-backend-webgl';
const plugin = requirePlugin("paddlejs-plugin");
plugin.register(paddlejs,wx);

let pdjs;
const initPaddle = () => {
  return new Promise((resolve, reject) => {
    pdjs = new paddlejs.Runner({
      modelPath:'http://127.0.0.1:3300/model.json',
      feedShape: {
        fw: 224,
        fh: 224
      },
      fill: '#fff',
      targetSize: {
        height: 224,
        width: 224
      },
      mean: [0.485, 0.456, 0.406],
      std: [0.229, 0.224, 0.225],
      webglFeedProcess: true,
    })
    pdjs.init().then(() => {
     // 初始化完成
      resolve(pdjs)
    })
  })
}

Page({
  data:{
    haveGetImgSrc: false,
    alreadyPredict:false,
    imgSrc:'',
    rpx: 1,
    imgObj:{},
    width:0,
    height:0
  },
  onLoad:function(options){
    let _this = this;
    wx.getSystemInfo({//获取手机系统信息
      success(res) {
        //求得px 和 rpx 的比例
        _this.data.rpx = res.screenWidth / 750;
      }
    })
  },
  onReady:function(){
    //页面渲染完成
  },
  onShow:function(){
    //页面显示
  },
  onHide:function(){
    //页面隐藏
  },
  onUnload:function(){
    //页面关闭
  },
  chooseImage() {
      // 通过相册选择图片,获取图片的像素信息作为模型输入
      const me = this;
      wx.chooseImage({
          count: 1,
          sizeType: ['original'],
          sourceType: ['album', 'camera'],
          success(res) {
              // tempFilePath可以作为img标签的src属性显示图片
              me.getImageInfo(res.tempFilePaths[0]);
          }
      });
  },
  getImageInfo:function(imgPath) {
      // 获取到图片的像素信息
      wx.showLoading({
        title: '',
      });

      const me = this;
      wx.getImageInfo({
          src: imgPath,
          success: (imgInfo) => {
              const {
                  width,
                  height,
                  path
              } = imgInfo;

              me.setData({
                width:width,
                height:height
              })

              const canvasId = 'myCanvas';
              // 获取页面中的canvas上下文
              const ctx = wx.createCanvasContext(canvasId,this);

              console.log("画布已创建")
              console.log("宽：",width);
              console.log("高：",height);
              
              let _this = this;
              if(width>=height){
                ctx.drawImage(path, 0, 0, 750*_this.data.rpx, 750/width*height* _this.data.rpx);
              }else if(width<height){
                ctx.drawImage(path, 0, 0, 750/height*width*_this.data.rpx, 750* _this.data.rpx);
              }
              
              this.setData({
                haveGetImgSrc: true
              });

              ctx.draw(false, () => {
                  //获取图像数据
                  wx.canvasGetImageData({
                      canvasId: canvasId,
                      x: 0,
                      y: 0,
                      width: width,
                      height: height,
                      success(res){
                        _this.imgObj={
                          data: res.data,
                          width: width,
                          height: height
                        };
                        wx.hideLoading();
                      },
                      fail(e) {
                        console.log("出错了：",e)
                        wx.hideLoading();
                      }
                  });
              });
          }
      });
  },
  async predict(){
    wx.showLoading({
      title: '',
    });

    let _this = this;
    // const itemMap = CONFIG.config.info.itemMap;
    const itemMap = RESULT.config.info.itemMap;

    await initPaddle();

    console.log("传入的数据:",_this.imgObj)
    pdjs.predict(_this.imgObj, function (res) {
      // 推理完成
      // console.log('res是：',res)
      const max = Math.max.apply(null, res);
      const index = res.indexOf(max);
      console.log(index)

      console.log("结果：",itemMap[index])

      wx.hideLoading();

      wx.showModal({
        cancelColor: "cancelColor",
        title:"识别结果",
        content:"可能是："+itemMap[index].name,
        showCancel:false,
        confirmText:"Got it.",
        confirmColor:"#c5b7e4"
      })

      _this.alreadyPredict=true;
      _this.setData({
        alreadyPredict:true
      })
     })
  },
  clearImgSrc() {
    let _this = this;
    wx.showModal({
      cancelColor: 'cancelColor',
      title:'提示',
      content:'确定清空图像？',
      confirmColor:"#c5b7e4",
      success:function(res){
        if(res.confirm){
          _this.setData({
            haveGetImgSrc: false,
            imgSrc: ''
          });
          const ctx = wx.createCanvasContext("myCanvas",this);
          ctx.draw();
        }
      }
    })
  }
})