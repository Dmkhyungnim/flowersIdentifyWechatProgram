const { envList } = require('../../envList.js');
Page({
  data: { 
    envList,
    selectedEnv: envList[0],
    haveCreateCollection: false,
    animation:{}
  },
  onLoad:function(){
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },
  onReady: function () {
    var count = 0;
    this.animation = wx.createAnimation({
      duration: 1000, // 动画持续时间，单位 ms
      timingFunction: 'linear', // 动画的效果
      delay: 100, // 动画延迟时间，单位 ms
      transformOrigin: '50% 50%' // 动画的中心点
    });
    
    setInterval(function() {
      if (count % 2 == 0) {
        this.animation.scale(1.0).step();
      } else {
        this.animation.scale(0.7).step();
      }
      
      this.setData({
        animation: this.animation.export()
      });
      
      count++;
      if (count == 1000) {
        count = 0;
      }
    }.bind(this), 1000);
  },
  jumpToIDF:function(){
    wx.navigateTo({
      url: '../identify/index',
    })
  }
});
