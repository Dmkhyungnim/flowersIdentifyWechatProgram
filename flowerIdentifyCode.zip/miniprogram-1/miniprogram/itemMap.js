export const RESULT = {
  config: {
      info: {
        itemMap: {
          2: {
            name: 'canterbury bells 风铃草'
          },
          28: {
            name: 'artichoke 朝鲜蓟'
          },
          29: {
            name: 'garden phlox 草夹竹桃'
          },
          31: {
            name: 'foxglove 毛地黄'
          },
          34: {
            name: 'alpine sea holly 高山海冬青'
          },
          45: {
            name: 'californian poppy 加州罂粟'
          },
          47: {
            name: 'buttercup 金凤花'
          },
          58: {
            name: 'fire lily 火百合'
          },
          71: {
            name: 'azalea 杜鹃花'
          },
          73:{
            name:'camellia 山茶'
          },
          76:{
            name:'passion flower 西番莲'
          },
          79:{
            name:'anthurium 安祖花'
          },
          80:{
            name:'frangipani 素馨花'
          },
          89:{
            name:'canna lily 大麻百合'
          }
        }
      }
    }
  }