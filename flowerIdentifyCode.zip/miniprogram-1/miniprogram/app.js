App({
  onLaunch: function () {
    this.globalData = {};
  }
});
