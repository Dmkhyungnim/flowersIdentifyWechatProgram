const envList = [{"envId":"cloud1-4g0ufnxa65a8e655","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}